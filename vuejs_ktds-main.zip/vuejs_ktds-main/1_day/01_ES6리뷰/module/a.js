//a.js

export var num = 10;

export function fun(){
    return "fun";
}

export class Person{

}

var num2 = 300;
class Person2{}

export {num2, Person2}
