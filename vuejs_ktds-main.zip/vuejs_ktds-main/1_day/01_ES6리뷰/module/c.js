// c.js
import {num,fun,Person} from './a.js';
import  str   from './b.js';
console.log(num);
fun();
var p = new Person();

console.log(str);