//b.js

// export default ()=>{
//     console.log("arrow fun");
// }
// export default  str = "hello";
const str = "hello";
export default str;